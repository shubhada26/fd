![foodfind](https://user-images.githubusercontent.com/64918749/126927969-85249f1c-507e-45c0-a955-6ac48a8d2d65.png)
# FoodFind
A MERN Stack app that finds nearby restaurants, and allows for user restaurant saving.

----------------------------------------------------------------------------------------------------------------------------------
>
> ![image](https://user-images.githubusercontent.com/64918749/126884631-05356411-fb61-4449-85f8-d3f6df86ed96.png)
> 
> ![image](https://user-images.githubusercontent.com/64918749/126884651-a8463476-ab88-4680-99fe-65e9a2a596a7.png)
> 
> ![image](https://user-images.githubusercontent.com/64918749/126884661-bded14a8-2c31-472c-8b5a-20973cdc5a15.png)
> 
> ![image](https://user-images.githubusercontent.com/64918749/126884717-0e4c468d-b4b0-49d4-8e8c-0e71ff90b7d4.png)
> 
> ![image](https://user-images.githubusercontent.com/64918749/126884723-ba6d05c0-f856-4c90-89c3-557de5aa22ab.png)
> 
> Currently being hosted as a Heroku app:
> https://foodfindapplication.herokuapp.com
>
----------------------------------------------------------------------------------------------------------------------------------

FoodFind -- Developed by Tristan Parry, 2021
